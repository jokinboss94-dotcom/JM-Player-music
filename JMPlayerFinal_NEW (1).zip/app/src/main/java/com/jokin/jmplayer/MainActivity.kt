
package com.jokin.jmplayer

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    val API_KEY = "AIzaSyCQV4sg1nwq52inh3W2OZCY62EloLSESG0" // Tvoj ključ

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val searchInput = findViewById<EditText>(R.id.searchInput)
        val searchButton = findViewById<Button>(R.id.searchButton)

        searchButton.setOnClickListener {
            val query = searchInput.text.toString()
            if (query.isEmpty()) {
                Toast.makeText(this, "Unesi naziv pjesme", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Tražim: $query", Toast.LENGTH_SHORT).show()
                // YouTube API call placeholder
            }
        }
    }
}
